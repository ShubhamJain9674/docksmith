#include "crypto.h"
#include <filesystem>
#include <iostream>

namespace fs = std::filesystem;

int main() {
    // Fix: remove the "=" after fs::path
    fs::path filePath = fs::absolute("alpine-minirootfs-3.18.0-x86_64.tar");
    
    std::string digest = encryptSHA256(filePath);
    
    if (!digest.empty()) {
        std::cout << "Digest: " << digest << std::endl;
    } else {
        std::cerr << "Failed to calculate digest" << std::endl;
        return 1;
    }
    
    return 0;
}